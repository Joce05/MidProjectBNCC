import java.util.Scanner;

public class Vehicle { //abstract
	String typeSS, brandSS, nameSS, licenseSS, typeVS;
	int topSpeedSS, gasCapSS, WheelSS;
	static Scanner scan = new Scanner(System.in);
	public void ent() {
		System.out.println("Vehicle has entertainment system");
	}
	static String brandGet() {
		boolean flag = false;
		String vStr = new String();
		while (!flag) {
			System.out.print("Input brand [>= 5]: ");
			vStr = scan.nextLine();
			if (vStr.length() >= 5) {
				flag = true;
			}
		}
		if (vStr.charAt(0) <= 'z' && vStr.charAt(0) >= 'a') {
			vStr = vStr.substring(0, 1).toUpperCase() + vStr.substring(1);
		}
		return vStr;
	}
	static String nameGet() {
		boolean flag = false;
		String vStr = new String();
		while (!flag) {
			System.out.print("Input name [>= 5]: ");
			vStr = scan.nextLine();
			if (vStr.length() >= 5) {
				flag = true;
			}
		}
		if (vStr.charAt(0) <= 'z' && vStr.charAt(0) >= 'a') {
			vStr = vStr.substring(0, 1).toUpperCase() + vStr.substring(1);
		}
		return vStr;
	}
	static String licenseGet() {
		boolean flag = false;
		String vLicensee = new String();
		while (!flag) {
			boolean c = true;
			System.out.print("Input license: ");
			vLicensee = scan.nextLine();
			int len = vLicensee.length();
			if (!((vLicensee.charAt(0) >= 'A' && vLicensee.charAt(0) <= 'Z' || vLicensee.charAt(0) >= 'a' && vLicensee.charAt(0) <= 'z') && vLicensee.charAt(1) == ' ')) {
				c = false;
			}
			int count;
			for (count = 2; count < 7 && c; count++) {
				if (!(vLicensee.charAt(count) >= '0' && vLicensee.charAt(count) <= '9') && vLicensee.charAt(count) != ' ' || count > len -1) {
					c = false;
					break;
				} else if (vLicensee.charAt(count) == ' ') {
					count++;
					break;
				} else if (count == 6){
					c = false;
					break;
				}
			}
			if (len - count -1 >= 3 || len - count -1 < 0) {
				c = false;
			}
			for (; count < len && c; count++) {
				if (!(vLicensee.charAt(count) >= 'A' && vLicensee.charAt(count) <= 'Z' || vLicensee.charAt(count) >= 'a' && vLicensee.charAt(count) <= 'z' )) {
					c = false;
					break;
				}
			}
			if (c) {
				flag = true;
			}
		}
		return vLicensee.toUpperCase();
	}
	static int speedGet() {
		boolean flag = false;
		int vTopSpeedd = 0;
		while (!flag) {
			System.out.print("Input top speed [100 <= topSpeed <= 250]: ");
			vTopSpeedd = scan.nextInt(); scan.nextLine();
			if (vTopSpeedd >= 100 && vTopSpeedd <= 250) {
				flag = true;
			}
		}
		return vTopSpeedd;
	}
	static int capGet() {
		boolean flag = false;
		int cap = 0;
		while (!flag) {
			System.out.print("Input gas capacity [30 <= gasCap <= 60]: ");
			cap = scan.nextInt(); scan.nextLine();
			if (cap <= 60 && cap >= 30) {
				flag = true;
			}
		}
		return cap;
	}
}

class Car extends Vehicle { //inheritance
	int entertainmentSystem;
	public void ent() { // override
		if (typeVS.equalsIgnoreCase("supercar")) {
			System.out.println("Boosting!");
		} else {
			System.out.println("Turning on entertainment system...");
		}
	}
	static int wheels() {
		while (true) {
			System.out.print("Input wheel [4 <= wheel <= 6]: ");
			int wheels = scan.nextInt(); scan.nextLine();
			if (wheels >= 4 && wheels <= 6) {
				return wheels;
			}
		}
	}
	public String typeFunc() {
		while (true) {
			boolean check = false;
			System.out.print("Input type [SUV | Supercar | Minivan]: ");
			String flag = scan.nextLine();
			if (flag.equalsIgnoreCase("suv") || flag.equalsIgnoreCase("supercar") || flag.equalsIgnoreCase("minivan")) {
				check = true;
			}
			if (check) {
				if (flag.equalsIgnoreCase("SUV")) {
					flag = flag.toUpperCase();
				} else {
					flag = flag.substring(0, 1).toUpperCase() + flag.substring(1).toLowerCase();
				}
				return flag;
			}
		}
	}
	public int entertainFunc() {
		while (true) {
			System.out.print("Input entertainment system amount [>= 1]: ");
			int ent = scan.nextInt(); scan.nextLine();
			if (ent >= 1) {
				return ent;
			}
		}
	}
 	public Car(String type) {
		typeSS = type;
		brandSS = brandGet();
		nameSS = nameGet();
		licenseSS = licenseGet();
		topSpeedSS = speedGet();
		gasCapSS = capGet();
		WheelSS = wheels();
		typeVS = typeFunc();
		entertainmentSystem = entertainFunc();
	}
}

class Motorcycle extends Vehicle { //inheritance
	int helmetSS;
	public void ent() { //override
		System.out.println(nameSS + " is standing!");
	}
	static int wheels() {
		while (true) {
			System.out.print("Input wheel [2 <= wheel <= 3]: ");
			int wheels = scan.nextInt(); scan.nextLine();
			if (wheels <= 3 && wheels >= 2) {
				return wheels;
			}
		}
	}
	public int helmSS() {
		while (true) {
			System.out.print("Input helmetSS amount [>= 1]: ");
			int helm = scan.nextInt(); scan.nextLine();
			if (helm >= 1) {
				return helm;
			}
		}
	}
	public String typeFunc() {
		while (true) {
			boolean check = false;
			System.out.print("Input type [Automatic | Manual]: ");
			String flag = scan.nextLine();
			if (flag.equalsIgnoreCase("automatic") || flag.equalsIgnoreCase("manual")) {
				check = true;
			}
			if (check) {
				flag = flag.substring(0, 1).toUpperCase() + flag.substring(1).toLowerCase();
				return flag;
			}
		}
	}
	public Motorcycle(String type) {
		typeSS = type;
		brandSS = brandGet();
		nameSS = nameGet();
		licenseSS = licenseGet();
		topSpeedSS = speedGet();
		gasCapSS = capGet();
		WheelSS = wheels();
		typeVS = typeFunc();
		helmetSS = helmSS();
	}
}