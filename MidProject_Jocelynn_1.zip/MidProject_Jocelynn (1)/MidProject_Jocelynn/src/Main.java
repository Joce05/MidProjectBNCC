import java.util.Scanner;
import java.util.Vector;

public class Main {
	static Scanner scan = new Scanner(System.in);
	public static void main(String[] args){
		Vector<Car> cars = new Vector<>();
		Vector<Motorcycle> motor = new Vector<>();
		String Typea;
		int ch = 0, totalcar = 0, totalmotor = 0;
		while (true) {
			System.out.println("1. Input");
			System.out.println("2. View");
			System.out.println("3. Exit Program");
			System.out.print("[Input]:");
			ch = scan.nextInt(); scan.nextLine();
			if (ch == 1) {
				Typea = typeGet();
				if (Typea.equalsIgnoreCase("car")) {
					totalcar++;
					cars.add(new Car(Typea));
				} else {
					totalmotor++;
					motor.add(new Motorcycle(Typea));
				}
				System.out.print("ENTER to return");
				scan.nextLine();
			} else if (ch == 2) {
				System.out.println("|----|--------------------|--------------------|");
				System.out.println("|No  |Type                |Name                |");
				System.out.println("|----|--------------------|--------------------|");
				for (int i = 0; i < totalcar; i++) {
					System.out.printf("|%-4d|%-20s|%-20s|\n", i+1, cars.get(i).typeVS, cars.get(i).nameSS);
				}
				System.out.println("|----|--------------------|--------------------|");
				for (int i = 0; i < totalmotor; i++) {
					System.out.printf("|%-4d|%-20s|%-20s|\n", i+totalcar+1, motor.get(i).typeVS, motor.get(i).nameSS);
				}
				System.out.println("|----|--------------------|--------------------|");
				System.out.print("Pick a vehicle number to test drive [Enter '0' to exit]: ");
				int choose = scan.nextInt(); scan.nextLine();
				if (choose >= 1 && choose <= totalmotor + totalcar) {
					System.out.println();
					if (choose > totalcar) {
						int index = choose - totalcar - 1;
						System.out.println("Brand: " + motor.elementAt(index).brandSS);
						System.out.println("Name: " + motor.elementAt(index).nameSS);
						System.out.println("License Plate: " + motor.elementAt(index).licenseSS);
						System.out.println("Type: " + motor.elementAt(index).typeVS);
						System.out.println("Gas Capacity: " + motor.elementAt(index).gasCapSS );
						System.out.println("Top Speed: " + motor.elementAt(index).topSpeedSS);
						System.out.println("Wheel(s): " + motor.elementAt(index).typeVS);
						System.out.println("Helm: " + motor.elementAt(index).helmetSS);
						motor.elementAt(index).ent();
						System.out.print("\nHelmet price: ");
						int priceHelmet = scan.nextInt(); scan.nextLine();
						System.out.println("Price: <Motorcycle Price> + " + priceHelmet * motor.elementAt(index).helmetSS);
					} else {
						int index = choose - 1;
						System.out.println("Brand: " + cars.elementAt(index).brandSS);
						System.out.println("Name: " + cars.elementAt(index).nameSS);
						System.out.println("License Plate: " + cars.elementAt(index).licenseSS);
						System.out.println("Type: " + cars.elementAt(index).typeVS);
						System.out.println("Gas Capacity: " + cars.elementAt(index).gasCapSS);
						System.out.println("Top Speed: " + cars.elementAt(index).topSpeedSS);
						System.out.println("Wheel(s): " + cars.elementAt(index).WheelSS);
						System.out.println("Entertainment System: " + cars.elementAt(index).entertainmentSystem);
						cars.elementAt(choose - 1).ent();
					}
					System.out.print("ENTER to continue");
					scan.nextLine();
				}
			} else if (ch == 3) {
				break;
			}
			System.out.println("\n");
		}
	}
	static String typeGet() {
		boolean x = false;
		String Typeax = new String();
		while (!x) {
			System.out.print("Input type [Car | Motorcycle]: ");
			Typeax = scan.nextLine();
		if (Typeax.equalsIgnoreCase("car") || Typeax.equalsIgnoreCase("motorcycle")) {
				x = true;
			}
		}
		return (Typeax.equalsIgnoreCase("car")? "Car" : "Motorcycle");
	}
}